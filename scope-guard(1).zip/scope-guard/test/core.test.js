import test from 'node:test';
import assert from 'node:assert/strict';
import { analyze, validateContract } from '../src/core.js';

const contract = {
  contractedHours: 100,
  startDate: '2026-01-01',
  endDate: '2026-06-30',
  warnAtPercent: 80,
  outOfScopeLabels: ['out-of-scope', 'change-request'],
};

const issue = (key, hours, extra = {}) => ({
  key,
  summary: `Issue ${key}`,
  type: 'Task',
  status: 'In Progress',
  labels: [],
  estimateSeconds: 0,
  worklogs: [{ date: '2026-02-10', seconds: hours * 3600 }],
  ...extra,
});

test('work inside the contract raises no flags', () => {
  const r = analyze({ contract, issues: [issue('A-1', 40)] });
  assert.equal(r.summary.usedHours, 40);
  assert.equal(r.summary.status, 'ok');
  assert.deepEqual(r.flags, []);
});

test('warns once the threshold is reached', () => {
  const r = analyze({ contract, issues: [issue('A-1', 85)] });
  assert.equal(r.summary.status, 'warning');
  assert.equal(r.flags[0].code, 'NEAR_LIMIT');
});

test('flags hours beyond the contracted amount', () => {
  const r = analyze({ contract, issues: [issue('A-1', 120)] });
  assert.equal(r.summary.status, 'over');
  assert.equal(r.summary.overageHours, 20);
  assert.equal(r.flags[0].code, 'OVER_BUDGET');
  assert.equal(r.flags[0].hours, 20);
});

test('exactly the contracted hours is a warning, not an overrun', () => {
  const r = analyze({ contract, issues: [issue('A-1', 100)] });
  assert.equal(r.summary.status, 'warning');
  assert.equal(r.summary.overageHours, 0);
});

test('out-of-scope labels are matched case-insensitively and do not consume the contract', () => {
  const r = analyze({ contract, issues: [issue('A-1', 60), issue('A-2', 10, { labels: ['Change-Request'] })] });
  assert.equal(r.summary.usedHours, 60);
  assert.equal(r.summary.outOfScopeHours, 10);
  assert.equal(r.issues[0].key, 'A-2');
  assert.equal(r.issues[0].reasons[0].code, 'OUT_OF_SCOPE');
  assert.ok(r.flags.some((f) => f.code === 'OUT_OF_SCOPE'));
});

test('issues outside the scope JQL are flagged, matching ones are counted', () => {
  const r = analyze({ contract, issues: [issue('A-1', 30), issue('A-2', 12)], inScopeKeys: new Set(['A-1']) });
  assert.equal(r.summary.usedHours, 30);
  assert.equal(r.summary.outOfScopeHours, 12);
  assert.equal(r.issues[0].reasons[0].text, 'Not matched by the scope JQL');
});

test('no scope JQL means every in-period issue is in scope', () => {
  const r = analyze({ contract, issues: [issue('A-1', 30), issue('A-2', 12)], inScopeKeys: null });
  assert.equal(r.summary.usedHours, 42);
  assert.equal(r.summary.outOfScopeHours, 0);
});

test('work before the start or after the end date is separated out', () => {
  const worklogs = [
    { date: '2025-12-15', seconds: 5 * 3600 },
    { date: '2026-03-01', seconds: 10 * 3600 },
    { date: '2026-07-02', seconds: 5 * 3600 },
  ];
  const r = analyze({ contract, issues: [issue('A-1', 0, { worklogs })] });
  assert.equal(r.summary.usedHours, 10);
  assert.equal(r.summary.outOfPeriodHours, 10);
  assert.ok(r.flags.some((f) => f.code === 'OUT_OF_PERIOD'));
});

test('blank dates mean no period limits', () => {
  const open = { ...contract, startDate: '', endDate: '' };
  const worklogs = [{ date: '1999-01-01', seconds: 3600 }, { date: '2099-01-01', seconds: 3600 }];
  const r = analyze({ contract: open, issues: [issue('A-1', 0, { worklogs })] });
  assert.equal(r.summary.usedHours, 2);
  assert.equal(r.summary.outOfPeriodHours, 0);
});

test('flags issues running well over their estimate', () => {
  const r = analyze({
    contract,
    issues: [issue('A-1', 8, { estimateSeconds: 4 * 3600 }), issue('A-2', 5, { estimateSeconds: 4 * 3600 })],
  });
  assert.deepEqual(r.issues.map((i) => i.key), ['A-1']);
  assert.equal(r.issues[0].reasons[0].code, 'OVER_ESTIMATE');
  assert.equal(r.flags.at(-1).code, 'OVER_ESTIMATE');
});

test('beyond-contract hours add up without double counting', () => {
  const r = analyze({
    contract,
    issues: [
      issue('A-1', 110),
      issue('A-2', 10, { labels: ['out-of-scope'] }),
      issue('A-3', 0, { worklogs: [{ date: '2025-11-01', seconds: 5 * 3600 }] }),
    ],
  });
  assert.equal(r.summary.usedHours, 110);
  assert.equal(r.summary.overageHours, 10);
  assert.equal(r.summary.outOfScopeHours, 10);
  assert.equal(r.summary.outOfPeriodHours, 5);
  assert.equal(r.summary.beyondContractHours, 25);
  assert.equal(r.summary.totalLoggedHours, 125);
});

test('validateContract accepts a good form and tidies it', () => {
  const { errors, value } = validateContract({
    name: '  SOW-14 ',
    contractedHours: '400',
    hourlyRate: '150',
    currency: 'eur',
    startDate: '2026-01-01T00:00:00.000Z',
    endDate: '2026-06-30',
    warnAtPercent: '',
    outOfScopeLabels: 'out-of-scope, change-request  out-of-scope',
    scopeJql: ' labels = contracted ',
  });
  assert.deepEqual(errors, []);
  assert.equal(value.name, 'SOW-14');
  assert.equal(value.contractedHours, 400);
  assert.equal(value.currency, 'EUR');
  assert.equal(value.startDate, '2026-01-01');
  assert.equal(value.warnAtPercent, 80);
  assert.deepEqual(value.outOfScopeLabels, ['out-of-scope', 'change-request']);
  assert.equal(value.scopeJql, 'labels = contracted');
});

test('validateContract rejects bad input', () => {
  const { errors } = validateContract({
    contractedHours: '0',
    hourlyRate: '',
    currency: 'dollars',
    startDate: '2026-02-30',
    endDate: 'soon',
    warnAtPercent: '150',
  });
  assert.equal(errors.length, 6);
  assert.ok(validateContract({ contractedHours: 10, hourlyRate: 5, startDate: '2026-05-02', endDate: '2026-05-01' }).errors[0].includes('End date'));
});
