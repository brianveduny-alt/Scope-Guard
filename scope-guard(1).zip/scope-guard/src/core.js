// Pure business logic. No Forge or Jira imports, so it runs under `npm test`.

const HOUR = 3600;
const OVER_ESTIMATE_RATIO = 1.5; // logged time is at least 150% of the original estimate...
const OVER_ESTIMATE_MIN_EXCESS_H = 2; // ...and at least this many hours above it
export const MAX_ROWS = 200;

export const CURRENCIES = ['USD', 'EUR', 'GBP', 'AUD', 'CAD', 'NZD', 'CHF', 'SEK', 'NOK', 'DKK', 'JPY', 'INR', 'SGD', 'ZAR', 'BRL', 'MXN'];
export const DEFAULT_LABELS = ['out-of-scope', 'change-request'];

const round = (n, digits = 2) => Math.round(n * 10 ** digits) / 10 ** digits;
const hours = (seconds) => round(seconds / HOUR);
const h = (n) => `${round(n)} h`;
const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
const num = (v) => (v === '' || v === null || v === undefined ? NaN : Number(v));

const isDate = (s) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
};

/** Checks and normalises what an admin typed into the contract form. */
export function validateContract(input = {}) {
  const errors = [];

  const contractedHours = num(input.contractedHours);
  if (!(contractedHours > 0) || contractedHours > 1e6) errors.push('Contracted hours must be a number greater than 0.');

  const hourlyRate = num(input.hourlyRate);
  if (!(hourlyRate >= 0) || hourlyRate > 1e7) errors.push('Billing rate must be a number, 0 or more.');

  const currency = String(input.currency || 'USD').toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) errors.push('Currency must be a 3-letter code such as USD.');

  const startDate = String(input.startDate || '').slice(0, 10);
  const endDate = String(input.endDate || '').slice(0, 10);
  if (startDate && !isDate(startDate)) errors.push('Start date is not a valid date.');
  if (endDate && !isDate(endDate)) errors.push('End date is not a valid date.');
  if (isDate(startDate) && isDate(endDate) && startDate > endDate) errors.push('End date must be on or after the start date.');

  const warnAtPercent = input.warnAtPercent === '' || input.warnAtPercent == null ? 80 : num(input.warnAtPercent);
  if (!(warnAtPercent >= 1 && warnAtPercent <= 100)) errors.push('Warning threshold must be between 1 and 100.');

  const rawLabels = Array.isArray(input.outOfScopeLabels) ? input.outOfScopeLabels.join(',') : String(input.outOfScopeLabels ?? '');
  const outOfScopeLabels = [...new Set(rawLabels.split(/[\s,]+/).filter(Boolean))];
  if (outOfScopeLabels.length > 25) errors.push('Use at most 25 out-of-scope labels.');

  const scopeJql = String(input.scopeJql || '').trim();
  if (scopeJql.length > 2000) errors.push('Scope JQL is too long (2,000 characters max).');

  const name = String(input.name || '').trim().slice(0, 120);

  return { errors, value: { name, contractedHours, hourlyRate, currency, startDate, endDate, warnAtPercent, outOfScopeLabels, scopeJql } };
}

/**
 * Compares logged work with the contract.
 *
 * issues: [{ key, summary, type, status, labels, estimateSeconds, worklogs: [{ date: 'YYYY-MM-DD', seconds }] }]
 * inScopeKeys: Set of issue keys matched by the scope JQL, or null when no scope JQL is set.
 *
 * Every logged second lands in exactly one bucket, so the buckets can be added up safely:
 *   counted      in period and in scope: consumes the contracted hours
 *   outOfScope   in period but on an out-of-scope issue (label, or not matched by the scope JQL)
 *   outOfPeriod  logged before the start date or after the end date
 */
export function analyze({ contract, issues, inScopeKeys = null }) {
  const { contractedHours, startDate, endDate, warnAtPercent } = contract;
  const labelSet = new Set((contract.outOfScopeLabels || []).map((l) => l.toLowerCase()));
  let counted = 0;
  let outOfScope = 0;
  let outOfPeriod = 0;
  let scopeIssues = 0;
  let periodIssues = 0;
  let overEstimateIssues = 0;
  const rows = [];

  for (const issue of issues) {
    let inPeriod = 0;
    let outside = 0;
    for (const w of issue.worklogs) {
      const early = startDate && w.date < startDate;
      const late = endDate && w.date > endDate;
      if (early || late) outside += w.seconds;
      else inPeriod += w.seconds;
    }
    const logged = inPeriod + outside;
    if (logged === 0) continue;

    const reasons = [];
    let scopeSeconds = 0;
    if (inPeriod > 0) {
      const label = (issue.labels || []).find((l) => labelSet.has(l.toLowerCase()));
      if (label) {
        reasons.push({ code: 'OUT_OF_SCOPE', text: `Labelled "${label}"` });
        scopeSeconds = inPeriod;
      } else if (inScopeKeys && !inScopeKeys.has(issue.key)) {
        reasons.push({ code: 'OUT_OF_SCOPE', text: 'Not matched by the scope JQL' });
        scopeSeconds = inPeriod;
      }
    }
    if (outside > 0) {
      reasons.push({ code: 'OUT_OF_PERIOD', text: `${h(outside / HOUR)} logged outside the contract period` });
    }
    const estimate = issue.estimateSeconds || 0;
    if (estimate > 0 && logged >= estimate * OVER_ESTIMATE_RATIO && logged - estimate >= OVER_ESTIMATE_MIN_EXCESS_H * HOUR) {
      reasons.push({ code: 'OVER_ESTIMATE', text: `${h(logged / HOUR)} logged against a ${h(estimate / HOUR)} estimate` });
      overEstimateIssues += 1;
    }

    counted += inPeriod - scopeSeconds;
    outOfScope += scopeSeconds;
    outOfPeriod += outside;
    if (scopeSeconds > 0) scopeIssues += 1;
    if (outside > 0) periodIssues += 1;
    if (reasons.length > 0) {
      rows.push({
        key: issue.key,
        summary: issue.summary,
        type: issue.type,
        status: issue.status,
        loggedHours: hours(logged),
        beyondHours: hours(scopeSeconds + outside),
        reasons,
      });
    }
  }

  const usedHours = counted / HOUR;
  const pct = (usedHours / contractedHours) * 100;
  const status = usedHours > contractedHours ? 'over' : pct >= warnAtPercent ? 'warning' : 'ok';
  const overageHours = Math.max(0, usedHours - contractedHours);
  const outOfScopeHours = outOfScope / HOUR;
  const outOfPeriodHours = outOfPeriod / HOUR;

  const flags = [];
  if (status === 'over') {
    flags.push({
      code: 'OVER_BUDGET',
      severity: 'critical',
      title: 'Contracted hours exceeded',
      detail: `${h(usedHours)} logged against ${h(contractedHours)} contracted, ${h(overageHours)} over.`,
      hours: round(overageHours),
    });
  } else if (status === 'warning') {
    flags.push({
      code: 'NEAR_LIMIT',
      severity: 'warning',
      title: `${Math.round(pct)}% of contracted hours used`,
      detail: `${h(contractedHours - usedHours)} left of ${h(contractedHours)}.`,
      hours: 0,
    });
  }
  if (outOfScope > 0) {
    flags.push({
      code: 'OUT_OF_SCOPE',
      severity: 'warning',
      title: 'Work logged outside the agreed scope',
      detail: `${h(outOfScopeHours)} on ${plural(scopeIssues, 'issue')} that carry an out-of-scope label or fall outside the scope JQL. These hours are not counted against the contract.`,
      hours: round(outOfScopeHours),
    });
  }
  if (outOfPeriod > 0) {
    flags.push({
      code: 'OUT_OF_PERIOD',
      severity: 'warning',
      title: 'Work logged outside the contract period',
      detail: `${h(outOfPeriodHours)} logged before the start date or after the end date, across ${plural(periodIssues, 'issue')}.`,
      hours: round(outOfPeriodHours),
    });
  }
  if (overEstimateIssues > 0) {
    flags.push({
      code: 'OVER_ESTIMATE',
      severity: 'info',
      title: 'Issues running well over estimate',
      detail: `${plural(overEstimateIssues, 'issue')} with logged time of at least ${OVER_ESTIMATE_RATIO * 100}% of the original estimate. Check whether the extra effort belongs in the agreed scope.`,
      hours: 0,
    });
  }

  rows.sort((a, b) => b.beyondHours - a.beyondHours || b.loggedHours - a.loggedHours);

  return {
    summary: {
      contractedHours,
      usedHours: round(usedHours),
      remainingHours: round(contractedHours - usedHours),
      percentUsed: round(pct, 1),
      status,
      overageHours: round(overageHours),
      outOfScopeHours: round(outOfScopeHours),
      outOfPeriodHours: round(outOfPeriodHours),
      beyondContractHours: round(overageHours + outOfScopeHours + outOfPeriodHours),
      totalLoggedHours: round((counted + outOfScope + outOfPeriod) / HOUR),
    },
    flags,
    issues: rows.slice(0, MAX_ROWS),
    issuesFlagged: rows.length,
  };
}
