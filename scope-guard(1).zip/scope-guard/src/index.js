import Resolver from '@forge/resolver';
import { kvs } from '@forge/kvs';
import { analyze, validateContract } from './core.js';
import { fetchProjectWork, isProjectAdmin, validateScopeJql, JiraError } from './jira.js';

const resolver = new Resolver();

// Keyed by project id so renaming a project key does not orphan the contract.
const storageKey = (project) => `contract:${project.id}`;

resolver.define('getReport', async ({ context }) => {
  const project = context.extension.project;
  const [isAdmin, contract] = await Promise.all([isProjectAdmin(project.key), kvs.get(storageKey(project))]);
  if (!contract) return { configured: false, isAdmin };

  // Billing rates (and every amount derived from them) are only sent to project admins.
  const visible = { ...contract, hourlyRate: isAdmin ? contract.hourlyRate : null };
  try {
    const work = await fetchProjectWork({
      projectKey: project.key,
      startDate: contract.startDate,
      scopeJql: contract.scopeJql,
    });
    const report = analyze({ contract, issues: work.issues, inScopeKeys: work.inScopeKeys });
    return { configured: true, isAdmin, contract: visible, truncated: work.truncated, ...report };
  } catch (e) {
    console.error('getReport failed', e);
    const error = e instanceof JiraError ? e.message : 'Something went wrong while reading work from Jira.';
    return { configured: true, isAdmin, contract: visible, error };
  }
});

resolver.define('saveContract', async ({ payload, context }) => {
  const project = context.extension.project;
  if (!(await isProjectAdmin(project.key))) {
    return { ok: false, errors: ['Only project administrators can change the contract.'] };
  }
  const { value, errors } = validateContract(payload);
  if (errors.length > 0) return { ok: false, errors };
  if (value.scopeJql) {
    const problem = await validateScopeJql(project.key, value.scopeJql);
    if (problem) return { ok: false, errors: [`Scope JQL: ${problem}`] };
  }
  await kvs.set(storageKey(project), { ...value, updatedBy: context.accountId, updatedAt: new Date().toISOString() });
  return { ok: true };
});

export const handler = resolver.getDefinitions();
