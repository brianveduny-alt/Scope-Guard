import api, { route } from '@forge/api';

// UI resolvers are stopped after 25 s, so stop paging early and report partial results.
const TIME_BUDGET_MS = 18000;
const GRACE_MS = 4000;
const PAGE_SIZE = 100;
export const MAX_ISSUES = 1000;

const ISSUE_FIELDS = ['summary', 'issuetype', 'status', 'labels', 'timeoriginalestimate', 'worklog'];
const JSON_HEADERS = { 'Content-Type': 'application/json', Accept: 'application/json' };

/** An error whose message is safe to show to the person using the app. */
export class JiraError extends Error {}

// Everything runs as the viewing user, so results respect their Jira permissions.
async function call(request, init) {
  const res = await api.asUser().requestJira(request, init);
  if (res.ok) return res.json();
  let detail = '';
  try {
    const body = await res.json();
    detail = [...(body.errorMessages || []), ...Object.values(body.errors || {})].join(' ');
  } catch {
    // The error response was not JSON.
  }
  throw new JiraError(detail || `Jira returned status ${res.status}.`);
}

const search = (body) =>
  call(route`/rest/api/3/search/jql`, { method: 'POST', headers: JSON_HEADERS, body: JSON.stringify(body) });

async function searchAll(jql, fields, deadline) {
  const issues = [];
  let nextPageToken;
  let truncated = false;
  do {
    const data = await search({ jql, fields, maxResults: PAGE_SIZE, ...(nextPageToken ? { nextPageToken } : {}) });
    issues.push(...data.issues);
    nextPageToken = data.nextPageToken;
    if (nextPageToken && (issues.length >= MAX_ISSUES || Date.now() > deadline)) {
      truncated = true;
      break;
    }
  } while (nextPageToken);
  return { issues, truncated };
}

// A search result carries at most 20 worklogs per issue; fetch the rest for busy issues.
async function fetchAllWorklogs(issueKey) {
  const worklogs = [];
  let startAt = 0;
  for (;;) {
    const data = await call(route`/rest/api/3/issue/${issueKey}/worklog?startAt=${startAt}&maxResults=1000`);
    worklogs.push(...data.worklogs);
    startAt += data.worklogs.length;
    if (data.worklogs.length === 0 || startAt >= data.total) return worklogs;
  }
}

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next;
      next += 1;
      out[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return out;
}

const shiftDays = (isoDate, days) => new Date(Date.parse(`${isoDate}T00:00:00Z`) + days * 86400000).toISOString().slice(0, 10);

/**
 * Reads every issue in the project with logged work, plus (when a scope JQL is set)
 * the keys of the issues that match it. Looks back 90 days before the contract start
 * so work logged just before it can be flagged.
 */
export async function fetchProjectWork({ projectKey, startDate, scopeJql }) {
  const deadline = Date.now() + TIME_BUDGET_MS;
  const since = startDate ? shiftDays(startDate, -90) : '2000-01-01';
  const base = `project = "${projectKey}" AND worklogDate >= "${since}"`;

  const [main, scope] = await Promise.all([
    searchAll(`${base} ORDER BY created ASC`, ISSUE_FIELDS, deadline),
    scopeJql ? searchAll(`${base} AND (${scopeJql}) ORDER BY created ASC`, ['summary'], deadline) : null,
  ]);

  let truncated = main.truncated;
  const issues = await mapLimit(main.issues, 5, async (issue) => {
    const f = issue.fields || {};
    const wl = f.worklog || { worklogs: [], total: 0 };
    let worklogs = wl.worklogs;
    if (wl.total > worklogs.length) {
      if (Date.now() < deadline + GRACE_MS) worklogs = await fetchAllWorklogs(issue.key);
      else truncated = true;
    }
    return {
      key: issue.key,
      summary: f.summary || '',
      type: f.issuetype?.name || '',
      status: f.status?.name || '',
      labels: f.labels || [],
      estimateSeconds: f.timeoriginalestimate || 0,
      worklogs: worklogs.map((w) => ({ date: String(w.started).slice(0, 10), seconds: w.timeSpentSeconds || 0 })),
    };
  });

  return { issues, inScopeKeys: scope ? new Set(scope.issues.map((i) => i.key)) : null, truncated };
}

/** Returns null when the JQL runs, otherwise Jira's explanation of what is wrong. */
export async function validateScopeJql(projectKey, scopeJql) {
  try {
    await search({ jql: `project = "${projectKey}" AND (${scopeJql})`, fields: ['summary'], maxResults: 1 });
    return null;
  } catch (e) {
    return e instanceof JiraError ? e.message : 'Jira could not run this JQL.';
  }
}

export async function isProjectAdmin(projectKey) {
  try {
    const data = await call(route`/rest/api/3/mypermissions?projectKey=${projectKey}&permissions=ADMINISTER_PROJECTS`);
    return data.permissions?.ADMINISTER_PROJECTS?.havePermission === true;
  } catch {
    return false;
  }
}
