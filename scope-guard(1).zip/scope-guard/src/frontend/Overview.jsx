import React from 'react';
import { Button, DynamicTable, Heading, Inline, Link, Lozenge, ProgressBar, SectionMessage, Stack, Text } from '@forge/react';

const SEVERITY = { critical: 'error', warning: 'warning', info: 'information' };
const STATUS = {
  ok: { appearance: 'success', label: 'Within contract' },
  warning: { appearance: 'moved', label: 'Nearing the limit' },
  over: { appearance: 'removed', label: 'Over contract' },
};

const hrs = (n) => `${Number(n.toFixed(1)).toLocaleString()} h`;

const formatMoney = (currency, amount, maxDigits = 0) => {
  try {
    return new Intl.NumberFormat(undefined, {
      style: 'currency',
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: maxDigits,
    }).format(amount);
  } catch {
    return `${currency} ${Math.round(amount).toLocaleString()}`;
  }
};

const periodText = ({ startDate, endDate }) => {
  if (startDate && endDate) return `${startDate} to ${endDate}`;
  if (startDate) return `From ${startDate}`;
  if (endDate) return `Until ${endDate}`;
  return 'No contract period set';
};

const Metric = ({ label, value, note }) => (
  <Stack space="space.050">
    <Text>{label}</Text>
    <Heading size="medium">{value}</Heading>
    {note ? <Text>{note}</Text> : null}
  </Stack>
);

const Header = ({ contract, isAdmin, loading, onRefresh, onEdit }) => (
  <Inline spread="space-between" alignBlock="center">
    <Stack space="space.050">
      <Heading size="large">{contract.name || 'Contract and logged work'}</Heading>
      <Text>{periodText(contract)}</Text>
    </Stack>
    <Inline space="space.100">
      <Button onClick={onRefresh} isLoading={loading}>
        Refresh
      </Button>
      {isAdmin ? (
        <Button appearance="primary" onClick={onEdit}>
          Edit contract
        </Button>
      ) : null}
    </Inline>
  </Inline>
);

const Overview = ({ data, loading, onRefresh, onEdit }) => {
  const { contract, summary: s, flags, issues, issuesFlagged, truncated, error, isAdmin } = data;
  const header = <Header contract={contract} isAdmin={isAdmin} loading={loading} onRefresh={onRefresh} onEdit={onEdit} />;

  if (error) {
    return (
      <Stack space="space.300">
        {header}
        <SectionMessage appearance="error" title="Couldn't read work from Jira">
          <Text>{error}</Text>
        </SectionMessage>
      </Stack>
    );
  }

  // rate is null for people who are not project admins: hide every amount.
  const rate = contract.hourlyRate;
  const money = (amount) => formatMoney(contract.currency, amount);
  const status = STATUS[s.status];
  const flagDetail = (f) =>
    rate != null && f.hours > 0 ? `${f.detail} At the contract rate that is about ${money(f.hours * rate)}.` : f.detail;

  const head = {
    cells: [
      { key: 'issue', content: 'Issue' },
      { key: 'summary', content: 'Summary' },
      { key: 'why', content: 'Why flagged' },
      { key: 'logged', content: 'Logged' },
      { key: 'beyond', content: 'Beyond contract' },
      ...(rate == null ? [] : [{ key: 'value', content: 'Value' }]),
    ],
  };
  const rows = issues.map((i) => ({
    key: i.key,
    cells: [
      { key: `${i.key}-issue`, content: <Link href={`/browse/${i.key}`}>{i.key}</Link> },
      { key: `${i.key}-summary`, content: i.summary },
      {
        key: `${i.key}-why`,
        content: (
          <Stack>
            {i.reasons.map((r) => (
              <Text key={r.code}>{r.text}</Text>
            ))}
          </Stack>
        ),
      },
      { key: `${i.key}-logged`, content: hrs(i.loggedHours) },
      { key: `${i.key}-beyond`, content: i.beyondHours > 0 ? hrs(i.beyondHours) : '-' },
      ...(rate == null ? [] : [{ key: `${i.key}-value`, content: i.beyondHours > 0 ? money(i.beyondHours * rate) : '-' }]),
    ],
  }));

  return (
    <Stack space="space.300">
      {header}

      <Stack space="space.100">
        <Inline space="space.100" alignBlock="center">
          <Lozenge appearance={status.appearance} isBold>
            {status.label}
          </Lozenge>
          <Text>{`${hrs(s.usedHours)} of ${hrs(s.contractedHours)} used (${s.percentUsed}%)`}</Text>
        </Inline>
        <ProgressBar value={Math.min(s.percentUsed / 100, 1)} ariaLabel={`${s.percentUsed}% of contracted hours used`} />
      </Stack>

      <Inline space="space.500" shouldWrap>
        <Metric
          label="Contracted"
          value={hrs(s.contractedHours)}
          note={rate == null ? undefined : `${money(s.contractedHours * rate)} at ${formatMoney(contract.currency, rate, 2)} per hour`}
        />
        <Metric
          label="In-scope hours logged"
          value={hrs(s.usedHours)}
          note={rate == null ? undefined : `${money(s.usedHours * rate)} of work`}
        />
        <Metric
          label={s.remainingHours >= 0 ? 'Remaining' : 'Over by'}
          value={hrs(Math.abs(s.remainingHours))}
        />
        <Metric
          label="Beyond the contract"
          value={hrs(s.beyondContractHours)}
          note={
            rate == null
              ? 'Over hours, out of scope and outside the period'
              : `About ${money(s.beyondContractHours * rate)} at risk of going unbilled`
          }
        />
      </Inline>

      {truncated ? (
        <SectionMessage appearance="warning" title="Partial results">
          <Text>
            This project has more logged work than the app can read in one request, so these figures may be incomplete. Set a later contract start date to read less history.
          </Text>
        </SectionMessage>
      ) : null}

      {flags.length === 0 ? (
        <SectionMessage appearance="success" title="No scope flags">
          <Text>All logged work falls inside the agreed hours, scope and period.</Text>
        </SectionMessage>
      ) : (
        flags.map((f) => (
          <SectionMessage key={f.code} appearance={SEVERITY[f.severity]} title={f.title}>
            <Text>{flagDetail(f)}</Text>
          </SectionMessage>
        ))
      )}

      {issues.length > 0 ? (
        <Stack space="space.100">
          <Heading size="medium">Flagged issues</Heading>
          <DynamicTable head={head} rows={rows} rowsPerPage={15} />
          {issuesFlagged > issues.length ? <Text>{`Showing the top ${issues.length} of ${issuesFlagged} flagged issues.`}</Text> : null}
        </Stack>
      ) : null}
    </Stack>
  );
};

export default Overview;
