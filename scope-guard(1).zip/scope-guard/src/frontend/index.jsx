import React, { useCallback, useEffect, useState } from 'react';
import ForgeReconciler, { SectionMessage, Spinner, Stack, Text } from '@forge/react';
import { invoke } from '@forge/bridge';
import Overview from './Overview.jsx';
import Settings from './Settings.jsx';

const App = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [editing, setEditing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setData(await invoke('getReport'));
      setFailed(false);
    } catch (e) {
      setFailed(true);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (!data) {
    return failed ? (
      <SectionMessage appearance="error" title="Couldn't load this page">
        <Text>Reload the page. If it keeps failing, run forge logs to see the error.</Text>
      </SectionMessage>
    ) : (
      <Spinner label="Loading contract" />
    );
  }

  if (data.isAdmin && (editing || !data.configured)) {
    return (
      <Settings
        contract={data.contract}
        firstRun={!data.configured}
        onCancel={() => setEditing(false)}
        onSaved={async () => {
          await load();
          setEditing(false);
        }}
      />
    );
  }

  if (!data.configured) {
    return (
      <SectionMessage title="No contract set up yet">
        <Text>A project administrator needs to enter the contracted hours and billing rate for this project.</Text>
      </SectionMessage>
    );
  }

  return (
    <Stack space="space.200">
      {failed ? (
        <SectionMessage appearance="error" title="Couldn't refresh">
          <Text>The figures below are from the last successful load.</Text>
        </SectionMessage>
      ) : null}
      <Overview data={data} loading={loading} onRefresh={load} onEdit={() => setEditing(true)} />
    </Stack>
  );
};

ForgeReconciler.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
