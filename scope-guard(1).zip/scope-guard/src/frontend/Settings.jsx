import React, { useState } from 'react';
import { invoke } from '@forge/bridge';
import { Button, DatePicker, Heading, HelperMessage, Inline, Label, SectionMessage, Select, Stack, Text, TextArea, Textfield } from '@forge/react';
import { CURRENCIES, DEFAULT_LABELS } from '../core.js';

const CURRENCY_OPTIONS = CURRENCIES.map((code) => ({ label: code, value: code }));

const toForm = (c) => ({
  name: c?.name ?? '',
  contractedHours: c?.contractedHours ?? '',
  hourlyRate: c?.hourlyRate ?? '',
  currency: c?.currency ?? 'USD',
  startDate: c?.startDate ?? '',
  endDate: c?.endDate ?? '',
  warnAtPercent: c?.warnAtPercent ?? 80,
  outOfScopeLabels: (c?.outOfScopeLabels ?? DEFAULT_LABELS).join(', '),
  scopeJql: c?.scopeJql ?? '',
});

const Field = ({ id, label, help, children }) => (
  <Stack space="space.050">
    <Label labelFor={id}>{label}</Label>
    {children}
    {help ? <HelperMessage>{help}</HelperMessage> : null}
  </Stack>
);

const Settings = ({ contract, firstRun, onSaved, onCancel }) => {
  const [form, setForm] = useState(() => toForm(contract));
  const [errors, setErrors] = useState([]);
  const [saving, setSaving] = useState(false);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));
  const text = (key) => (e) => set(key, e.target.value);
  // The date picker may hand back a full ISO time; keep only the date.
  const date = (key) => (value) => set(key, String(value || '').slice(0, 10));

  const save = async () => {
    setSaving(true);
    setErrors([]);
    try {
      const res = await invoke('saveContract', form);
      if (res.ok) {
        await onSaved();
        return;
      }
      setErrors(res.errors);
    } catch (e) {
      setErrors(['The contract could not be saved. Try again.']);
    }
    setSaving(false);
  };

  return (
    <Stack space="space.300">
      <Heading size="large">{firstRun ? 'Set up the contract' : 'Edit contract'}</Heading>

      {firstRun ? (
        <SectionMessage title="Enter what was agreed with the client">
          <Text>The app compares these terms with the time logged on this project's issues and flags work that looks outside them.</Text>
        </SectionMessage>
      ) : null}

      {errors.length > 0 ? (
        <SectionMessage appearance="error" title="Fix these before saving">
          {errors.map((message) => (
            <Text key={message}>{message}</Text>
          ))}
        </SectionMessage>
      ) : null}

      <Field id="name" label="Contract name (optional)" help="Shown at the top of the page, for example the SOW number.">
        <Textfield id="name" defaultValue={form.name} onChange={text('name')} />
      </Field>

      <Field id="hours" label="Contracted hours" help="Total hours the client agreed to pay for. Numbers only.">
        <Textfield id="hours" defaultValue={String(form.contractedHours)} onChange={text('contractedHours')} />
      </Field>

      <Inline space="space.200" shouldWrap>
        <Field id="rate" label="Billing rate per hour" help="Only project admins see rates and amounts.">
          <Textfield id="rate" defaultValue={String(form.hourlyRate)} onChange={text('hourlyRate')} />
        </Field>
        <Field id="currency" label="Currency">
          <Select
            inputId="currency"
            options={CURRENCY_OPTIONS}
            defaultValue={CURRENCY_OPTIONS.find((o) => o.value === form.currency)}
            onChange={(option) => set('currency', option.value)}
          />
        </Field>
      </Inline>

      <Inline space="space.200" shouldWrap>
        <Field id="start" label="Start date (optional)" help="Time logged before this date is flagged.">
          <DatePicker id="start" defaultValue={form.startDate} onChange={date('startDate')} />
        </Field>
        <Field id="end" label="End date (optional)" help="Time logged after this date is flagged.">
          <DatePicker id="end" defaultValue={form.endDate} onChange={date('endDate')} />
        </Field>
      </Inline>

      <Field id="warn" label="Warn when this % of hours is used" help="Between 1 and 100.">
        <Textfield id="warn" defaultValue={String(form.warnAtPercent)} onChange={text('warnAtPercent')} />
      </Field>

      <Field
        id="labels"
        label="Out-of-scope labels"
        help="Work on issues with any of these labels is flagged as out of scope. Separate labels with commas."
      >
        <Textfield id="labels" defaultValue={form.outOfScopeLabels} onChange={text('outOfScopeLabels')} />
      </Field>

      <Field
        id="jql"
        label="Scope JQL (optional)"
        help="Matches the issues that are in scope, for example: parent in (ABC-1, ABC-2) OR component = Website. Work on any other issue is flagged. Leave out ORDER BY."
      >
        <TextArea id="jql" defaultValue={form.scopeJql} onChange={text('scopeJql')} />
      </Field>

      <Inline space="space.100">
        <Button appearance="primary" onClick={save} isLoading={saving}>
          Save contract
        </Button>
        {firstRun ? null : (
          <Button onClick={onCancel} isDisabled={saving}>
            Cancel
          </Button>
        )}
      </Inline>
    </Stack>
  );
};

export default Settings;
