# Scope Guard

A Jira Forge app that compares a project's contracted hours and billing rate with the work logged in Jira, and flags work that looks outside the agreement. It adds a **Scope Guard** tab to each project.

## Deploy

```
npm install -g @forge/cli
forge login
npm install
forge register                  # writes a new app id into manifest.yml
forge deploy -e development
forge install -e development    # choose Jira and your site
```

Open a project and select **Scope Guard**. A project admin enters the contract; anyone who can browse the project sees the hours.

## What gets flagged

Every logged hour lands in exactly one bucket, so the numbers add up:

| Bucket | Meaning | Counts against contracted hours |
| --- | --- | --- |
| In scope | Logged inside the period on an in-scope issue | Yes |
| Out of scope | Logged inside the period on an issue with an out-of-scope label, or one the scope JQL does not match | No |
| Outside period | Logged before the start date or after the end date | No |

Flags raised:

- **Contracted hours exceeded**, and a warning at the threshold you set (default 80%).
- **Work outside the agreed scope**, with the issues listed.
- **Work outside the contract period**.
- **Issues running well over estimate** (logged at least 150% of the original estimate and 2 h or more above it). This is informational.

"Beyond the contract" is hours over the limit, plus out-of-scope hours, plus outside-period hours. For admins it is also shown as a value at the billing rate.

## Who sees what

- Only project admins (Administer Projects permission) can edit the contract or see the billing rate and any amounts. Everyone else sees hours only. The rate is withheld by the backend, not just hidden in the UI.
- Reports run as the person viewing the page, so anyone who cannot see some issues or worklogs will see lower totals.

## Limits

- Reads up to 1,000 issues with logged work and stops after about 18 seconds (Forge UI resolvers are cut off at 25 s). A "Partial results" banner appears when that happens; a later contract start date reads less history.
- Looks back 90 days before the start date so work logged just before the contract can be flagged.
- Worklogs are compared by the calendar date Jira reports for them.
- Time tracking must be enabled on the project.
- The contract is stored per project in Forge key-value storage under `contract:<projectId>`.

## Layout

```
manifest.yml            module, scopes, runtime
src/core.js             contract validation and the comparison logic (pure, tested)
src/jira.js             Jira REST calls (search, worklogs, permission check)
src/index.js            resolvers: getReport, saveContract
src/frontend/           UI Kit: Overview.jsx, Settings.jsx
test/core.test.js       run with `npm test` (Node 22+)
```
